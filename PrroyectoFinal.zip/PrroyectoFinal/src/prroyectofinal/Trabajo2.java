
package prroyectofinal;

import java.util.Scanner;


public class Trabajo2 {
    public static void main(String[] args) {
        
        /*
      Ejercicio 2(maquina de vetas)
        
    Escribir un programa que gestione el cobro de una maquina expendedora de
    golosinas 
    El programa que se pide consiste en que se puedan ingresar dos valores.
    Uno es el precio del producto y el otro es la cantidad de dinero que ingresa
    al usuario.
    El programa deberá calcular el vuelto, teniendo en cuenta que se trata de dar
    la menor cantidad de billetes. Ejemplo, si hay que devolver $60, lo ideal
    seria devolver primero $50 y despues $10 (NO 6 billetes de $10 ni 3 billetes
    de $20)
    Para poder representarlo, indicar cuales y cuantos billetes se deben dar 
    para entregar un vuelto. Tendremos en cuenta para este ejercicio que se 
    utilizaran billetes de $100, $50, $20, $10, $5, $2, y $1
    */

     maquinaDeVenta();   
       
    }
    
    public static void maquinaDeVenta (){
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingresar precio del producto: ");
        int precioProducto = teclado.nextInt();
        
        System.out.print("Cantidad de dinero a pagara: ");
        int cantidadIngresado = teclado.nextInt();
        
        int vuelto= restarDosEnteros(cantidadIngresado, precioProducto);
        
        int[] dineroVuelto = {100,50,20,10,5,2,1};
        
        
        if(precioProducto==cantidadIngresado){
            System.out.println("Usted pago con el cambio justo");
        }else if(precioProducto>cantidadIngresado){
            System.out.println("Dinero insuficiente!");
            
        }else
        System.out.print("Su vuelto son, ");
        for(int d:dineroVuelto){
            int cantidadBilletes = dividirDosEnteros(vuelto, d);
            vuelto=calcularResto(vuelto, d);
            if (cantidadBilletes>0){
                System.out.println(cantidadBilletes+" billete/s de $" +d);}
        }
        
    }
    
    public static int restarDosEnteros(int num1,int num2){
        return num1-num2;
    }
    
    public static int dividirDosEnteros(int num1,int num2){
        return num1/num2;
    }
    
    public static int calcularResto(int num1,int num2){
        return num1%num2;
    }
    

    
    
    
}

