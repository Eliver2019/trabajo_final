
package prroyectofinal;

import java.util.Scanner;

public class Trabajo1 {
    public static void main(String[] args) {
        
        /*
       Ejercicio 1(notas del alumno)
        
        Escribir un programa que permita el ingreso de la cantidad de notas a cargar,
        luego, que permita ingresar cada una de las notas y mostrar por la pantalla:
        
        - Promedio de las notas ingresadas.
        - Mensaje de "APROBADO" si el promedio es mayor o igual a 6.
        - Mensaje de "NO APROBADO" en caso de que el promedio sea menor a 6
          y que alguna de las notas cargadas sea menor o igual a 3.
        - Mensaje de "A RECUPERATORIO" en caso de que el promedio sea menor
        a 6 y que ninguna de las notas sea menor o igual a 3.
        */   
        notasDeAlumnos();  
    }
    
        public static void notasDeAlumnos(){
    int[] totalDeNotas= cargaDeNotas();
        System.out.println("Las notas ingresadas son: ");
        for(int t:totalDeNotas)System.out.print(t+" / ");
        System.out.println("");
    if(obtenerPromedioNotas(totalDeNotas)>=6){
        System.out.println("\"APROBADO\"");
    }else if(notaMenorTres(totalDeNotas)){
        System.out.println("\"NO APROBADO\"");
    }else{
        System.out.println("\"A RECUPERATORIO\"");
        }     

    
    }
     
    public static int[] cargaDeNotas(){
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese la cantidad de notas: ");
        int cantidadDeNotas= teclado.nextInt();
        int []notas= new int[cantidadDeNotas];
        for(int i=0; i<notas.length; i++){
            System.out.print("Ingrese la nota n°"+(i+1)+": ");
            notas[i]=teclado.nextInt();
        }
        return notas;
    }
    public static int sumarNotas(int[]notas){
        int sumaTotalNotas= 0;
        for(int n:notas) sumaTotalNotas+=n;
            return sumaTotalNotas;
        }
    
    public static int obtenerPromedioNotas(int[]notas){
        int promedio= sumarNotas(notas)/ notas.length;
        return promedio;
        }
    
    public static boolean notaMenorTres(int[] notas){
        boolean log= false;
        for(int n:notas){
            if(n<=3){
            log= true;
          }break;
        }
        return log;
    }
    
}

     

        
  
    
            
        

